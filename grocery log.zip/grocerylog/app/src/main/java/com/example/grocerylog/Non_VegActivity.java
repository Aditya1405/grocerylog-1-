package com.example.grocerylog;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Non_VegActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non__veg);
        setTitle("Non-Veg");
    }
}