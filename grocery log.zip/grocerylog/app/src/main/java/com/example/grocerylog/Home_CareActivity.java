package com.example.grocerylog;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Home_CareActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home__care);
        setTitle("Homecare");
    }
}