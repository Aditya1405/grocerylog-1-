package com.example.grocerylog;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FruitsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fruits);
        setTitle("Fruits");
    }
}